function getWeather() {
    const apiKey = '7ded80d91f2b280ec979100cc8bbba94';
    const location = document.getElementById('locationInput').value;

    // Zapytanie asynchroniczne do API Current Weather
    const currentWeatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${apiKey}`;
    const currentWeatherRequest = new XMLHttpRequest();
    currentWeatherRequest.open('GET', currentWeatherUrl, true);

    currentWeatherRequest.onload = function() {
        if (currentWeatherRequest.status >= 200 && currentWeatherRequest.status < 400) {
            const data = JSON.parse(currentWeatherRequest.responseText);
            displayCurrentWeather(data);
        } else {
            console.error('Błąd pobierania danych pogodowych');
        }
    };

    currentWeatherRequest.onerror = function() {
        console.error('Błąd żądania');
    };

    currentWeatherRequest.send();

    // Zapytanie asynchroniczne do API 5 day forecast
    fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${location}&appid=${apiKey}`)
        .then(response => response.json())
        .then(data => displayForecast(data))
        .catch(error => console.error('Błąd pobierania prognozy:', error));
}

function displayCurrentWeather(data) {
    const currentWeatherDiv = document.getElementById('currentWeather');
    const temperatureInCelsius = (data.main.temp - 273.15).toFixed(2); // Konwersja na stopnie Celsjusza
    const weatherInfo = `
        <h2>Pogoda bieżąca w ${data.name}</h2>
        <p>Temperatura: ${temperatureInCelsius} &deg;C</p>
        <p>Opis: ${data.weather[0].description}</p>
        <p>Wilgotność: ${data.main.humidity}%</p>
        <p>Prędkość wiatru: ${data.wind.speed} m/s</p>
        <p>Ciśnienie atmosferyczne: ${data.main.pressure} hPa</p>
    `;
    currentWeatherDiv.innerHTML = weatherInfo;
}

function displayForecast(data) {
    const forecastWeatherDiv = document.getElementById('forecastWeather');
    let forecastInfo = `<h2>Prognoza dla kolejnych dni:</h2>`;

    for (let i = 0; i < data.list.length; i++) {
        const forecast = data.list[i];
        const temperatureInCelsius = (forecast.main.temp - 273.15).toFixed(2); // Konwersja na stopnie Celsjusza
        forecastInfo += `
            <p>Data: ${forecast.dt_txt}</p>
            <p>Temperatura: ${temperatureInCelsius} &deg;C</p>
            <p>Opis: ${forecast.weather[0].description}</p>
            <p>Wilgotność: ${forecast.main.humidity}%</p>
            <p>Prędkość wiatru: ${forecast.wind.speed} m/s</p>
            <p>Ciśnienie atmosferyczne: ${forecast.main.pressure} hPa</p>
            <hr>
        `;
    }

    forecastWeatherDiv.innerHTML = forecastInfo;
}
