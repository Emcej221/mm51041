class Todo {
    constructor() {
        this.tasks = [];
        this.taskList = document.getElementById("task-list");
        this.newTaskInput = document.getElementById("new-task");
        this.dueDateInput = document.getElementById("due-date");
        this.addTaskButton = document.getElementById("add-task");
        this.searchInput = document.getElementById("search");
    }

    validateTask(task, date) {
        const now = new Date();
        return task.length >= 3 && task.length <= 255 && (date === "" || new Date(date) > now);
    }

    addTask(task, date) {
        if (this.validateTask(task, date)) {
            this.tasks.push({ text: task, date: date }); // Store task as an object with text and date properties
            this.draw();
            this.saveTasksToLocalStorage();
        } else {
            alert("Nieprawidłowe zadanie lub data!");
        }
    }

    deleteTask(index) {
        this.tasks.splice(index, 1);
        this.draw();
        this.saveTasksToLocalStorage();
    }

    saveTasksToLocalStorage() {
        const dataToSave = {
            tasks: this.tasks,
            dueDate: this.dueDateInput.value
        };
        localStorage.setItem("tasks", JSON.stringify(dataToSave));
    }

    loadTasksFromLocalStorage() {
        const savedData = JSON.parse(localStorage.getItem("tasks") || "{}");
        this.tasks = savedData.tasks || [];
        this.dueDateInput.value = savedData.dueDate || "";
        this.draw();
    }

    searchTasks() {
        const searchText = this.searchInput.value.trim().toLowerCase();
        if (searchText.length < 2) {
            this.draw();
            return;
        }

        this.draw();
        this.taskList.querySelectorAll(".task-text").forEach((taskText, index) => {
            const taskTextContent = taskText.innerHTML.toLowerCase();
            if (!taskTextContent.includes(searchText)) {
                taskText.parentElement.parentElement.style.display = "none";
            } else {
                taskText.innerHTML = taskTextContent.replace(new RegExp(searchText, "gi"), match => `<span class="highlight">${match}</span>`);
            }
        });
    }

    draw() {
        this.taskList.innerHTML = "";
        this.tasks.forEach((task, index) => {
            const li = document.createElement("li");
            const taskContainer = document.createElement("div");
            taskContainer.className = "task-container";

            // Tekst zadania
            const taskText = document.createElement("span");
            taskText.innerHTML = task.text; // Use task text property
            taskText.className = "task-text";

            // Data zadania
            const taskDate = document.createElement("span");
            taskDate.innerHTML = task.date; // Use task date property
            taskDate.className = "task-date";

            // Przycisk "Usuń"
            const deleteButton = document.createElement("button");
            deleteButton.innerHTML = "Usuń";
            deleteButton.className = "delete-button";

            taskContainer.appendChild(taskText);
            taskContainer.appendChild(taskDate);
            taskContainer.appendChild(deleteButton);
            li.appendChild(taskContainer);
            this.taskList.appendChild(li);

            taskText.addEventListener("click", () => {
                this.editTask(taskText);
            });

            deleteButton.addEventListener("click", (event) => {
                this.deleteTask(index);
                event.stopPropagation();
            });
        });
    }

    editTask(taskTextElement) {
        const taskText = taskTextElement.textContent;
        const listItem = taskTextElement.closest("li");
        const taskIndex = Array.from(this.taskList.children).indexOf(listItem);

        listItem.setAttribute("data-index", taskIndex);

        taskTextElement.innerHTML = '';
        const taskInput = document.createElement("input");
        taskInput.value = taskText;
        taskInput.className = "task-input";

        taskTextElement.appendChild(taskInput);

        taskInput.addEventListener("blur", () => {
            this.saveTaskEdit(taskInput, listItem);
        });

        taskInput.focus();
    }

    saveTaskEdit(taskInput, listItem) {
        const updatedTask = taskInput.value;
        listItem.querySelector(".task-text").textContent = updatedTask;
        listItem.querySelector(".task-date").textContent = this.dueDateInput.value;

        const index = parseInt(listItem.getAttribute("data-index"), 10);

        console.log("Updating task at index:", index);

        if (index >= 0 && index < this.tasks.length) {
            this.tasks[index] = { text: updatedTask, date: this.dueDateInput.value };
            console.log("Tasks after update:", this.tasks);
            this.saveTasksToLocalStorage();
        } else {
            console.error("Invalid task index:", index);
        }
    }
}

const todo = new Todo();

todo.loadTasksFromLocalStorage();

todo.addTaskButton.addEventListener("click", () => {
    todo.addTask(todo.newTaskInput.value, todo.dueDateInput.value);
});

todo.searchInput.addEventListener("input", () => todo.searchTasks());
